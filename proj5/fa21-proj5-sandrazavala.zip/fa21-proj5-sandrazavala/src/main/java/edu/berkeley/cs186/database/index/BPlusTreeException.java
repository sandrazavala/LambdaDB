package edu.berkeley.cs186.database.index;

@SuppressWarnings("serial")
public class BPlusTreeException extends RuntimeException {
    public BPlusTreeException(String message) {
        super(message);
    }
}
